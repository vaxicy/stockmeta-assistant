import os, shutil, zipfile

base = os.path.dirname(os.path.abspath(__file__))
print("base:", base)

# remove any existing zips so we don't include / re-zip them
for f in os.listdir(base):
    if f.endswith(".zip"):
        os.remove(os.path.join(base, f))
        print("removed", f)

# exclusion rules
EXCLUDE_DIRS = {".git", ".codebuddy", "node_modules", "__pycache__",
                "store-assets", "docs", "scripts", "assets"}
EXCLUDE_FILES = {"stockmeta-assistant-1.0.8.zip", "stockmeta-assistant-1.1.0.zip"}

names = []
for r, dirs, fs in os.walk(base):
    # prune excluded dirs in place
    dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
    for fn in fs:
        full = os.path.join(r, fn)
        rel = os.path.relpath(full, base)
        if fn in EXCLUDE_FILES:
            continue
        if fn.endswith(".zip"):
            continue
        names.append(rel)

out = os.path.join(base, "stockmeta-assistant-1.1.0.zip")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for rel in sorted(names):
        z.write(os.path.join(base, rel), arcname=rel)

print("packaged files:", len(names))
print("->", out)
