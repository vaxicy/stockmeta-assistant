param([string]$src)
$ErrorActionPreference = 'Stop'
$out = Join-Path $src 'stockmeta-assistant-1.0.8.zip'
if (Test-Path $out) { Remove-Item $out -Force }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$fs = [System.IO.Compression.ZipFile]::Open($out, 'Create')
$exclude = @('.codebuddy', '.git')
function AddDir($dir) {
  Get-ChildItem $dir -Force | ForEach-Object {
    $rel = $_.FullName.Substring($src.Length + 1).Replace('\', '/')
    $skip = $false
    foreach ($x in $exclude) { if ($rel -eq $x -or $rel.StartsWith($x + '/')) { $skip = $true } }
    if ($skip) { return }
    if ($_.PSIsContainer) { AddDir $_.FullName }
    else { [System.IO.Compression.ZipFile]::CreateEntryFromFile($fs, $_.FullName, $rel) | Out-Null }
  }
}
AddDir $src
$fs.Dispose()
Write-Host 'ZIP_CREATED'
(Get-Item $out).Length
