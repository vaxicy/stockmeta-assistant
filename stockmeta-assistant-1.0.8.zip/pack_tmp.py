import os, zipfile, shutil

SRC = r'd:\迅雷下载\vibe coding\Chrome Extensions\stockmeta-assistant'
OUT = os.path.join(SRC, 'stockmeta-assistant-1.0.8.zip')
EXCLUDE = {'.codebuddy', '.git'}

if os.path.exists(OUT):
    os.remove(OUT)

def walk(dirpath, base):
    for name in os.listdir(dirpath):
        full = os.path.join(dirpath, name)
        rel = os.path.relpath(full, base).replace(os.sep, '/')
        top = rel.split('/')[0]
        if top in EXCLUDE:
            continue
        if os.path.isdir(full):
            walk(full, base)
        else:
            with zipfile.ZipFile(OUT, 'a', zipfile.ZIP_DEFLATED) as z:
                z.write(full, rel)

walk(SRC, SRC)
print('ZIP_CREATED', os.path.getsize(OUT))
